from typing import _SpecialForm
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

from sqlalchemy.orm import backref

db = SQLAlchemy()

date = datetime.now()

def connect_db(app):
    db.app = app
    db.init_app(app)


class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer,
                    primary_key = True,
                    autoincrement = True,
                    nullable = True)

    first_name = db.Column(db.String(20),
                    nullable = False,
                    unique = False)

    last_name = db.Column(db.String(20),
                    nullable = False,
                    unique = False)

    image_url = db.Column(db.String(500),
                    nullable = True,
                    unique = False)
    
    
    def get_full_name(self):
        return f"{self.first_name} {self.last_name}"

class Post(db.Model):

    __tablename__ = 'posts'

    id = db.Column(db.Integer,
                    primary_key = True,
                    autoincrement = True)

    title = db.Column(db.String(100),
                    nullable = False)

    content = db.Column(db.Text,
                    nullable = False)

    created_at = db.Column(db.String(100),
                    nullable= False,
                    default= date)

    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))

    user = db.relationship('User', backref='posts') 
    tags = db.relationship('PostTag', backref ='post')

class PostTag(db.Model):

    __tablename__ = 'post_tags'

    post_id = db.Column(db.Integer,
                    db.ForeignKey("posts.id"),
                    primary_key = True)

    tag_id = db.Column(db.Integer,
                    db.ForeignKey("tags.id"),
                    primary_key = True)

class Tag(db.Model):

    __tablename__ = 'tags'

    id = db.Column(db.Integer,
                    primary_key = True,
                    autoincrement = True)

    name = db.Column(db.Text,
                    nullable = False,
                    unique = True)

    tags = db.relationship('PostTag', backref = 'tag')
    
