from flask import Flask, request, render_template, redirect, flash, session
from flask_debugtoolbar import DebugToolbarExtension
from sqlalchemy.sql.schema import ForeignKey
from models import db, connect_db, User, Post, PostTag, Tag

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql:///blogly_db'
app.config['SECRET_KEY'] = "secretkey"
app.config['DEBUG_TB_INTERCEPT_REDIRECTS'] = False
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ECHO'] = True

 
debug = DebugToolbarExtension(app)


connect_db(app)

@app.route('/')
def home_page():
    return redirect('/users')

@app.route('/users')
def list_users():
    """Show list of all users in DB"""
    users = User.query.all()
    return render_template('list.html', users = users)

@app.route('/users/new')
def create_user():
    return render_template("add.html")

@app.route('/users/add', methods=["POST"])
def add_user():
    first_name = request.form["first_name"]
    last_name = request.form["last_name"]
    image_url = request.form["image_url"]

    new_user = User(first_name= first_name, last_name= last_name, image_url = image_url)
    db.session.add(new_user)
    db.session.commit()

    return redirect(f"/users/{new_user.id}")

@app.route('/users/<int:user_id>')
def show_user(user_id):
    """Show details about single user"""
    user = User.query.get_or_404(user_id)
    posts = Post.query.all()
    return render_template("details.html", user = user, posts = posts)


@app.route('/users/<int:user_id>/delete')
def delete_user(user_id):

    user = User.query.filter_by(id = user_id).one()
  
    Post.query.filter_by(user_id = user.id).delete()
    User.query.filter_by(id = user_id).delete()
    db.session.commit()

    # flash("Warning: Deleting a user will delete all of the user's posts.")
    return redirect('/users')

@app.route('/users/<int:user_id>/posts/new')
def new_post(user_id):
    user = User.query.get_or_404(user_id)
    tags = Tag.query.all()
    return render_template("postform.html", user = user, tags = tags)

@app.route('/users/<int:user_id>/posts/new', methods=["POST"])
def submit_post(user_id):
    title= request.form["title"]
    content = request.form["content"]
    # tag_ids = [int(num) for num in request.form.getlist("checkbox")]
    # tags = Tag.query.filter(Tag.id.in_(tag_ids)).all()
#     **don't forget to re-include tags = tags in the new_post = Post() line
# **
    user = User.query.get_or_404(user_id)
    new_post = Post(title= title, content = content, user_id= user_id)
    db.session.add(new_post)
    db.session.commit()

    return redirect(f"/users/{user.id}")

@app.route ('/posts/<int:post_id>')
def show_post(post_id):
    post = Post.query.filter(Post.id == post_id).one()
    title= post.title
    content= post.content
    user = post.user
    first_name = post.user.first_name
    last_name = post.user.last_name
    fullname = f"{first_name} {last_name}"
    return render_template('/postdetail.html', title = title, content = content, fullname = fullname, user = user, post = post)

@app.route('/posts/<int:post_id>/edit')
def edit_post(post_id):
    post = Post.query.filter(Post.id == post_id).one()
    title= post.title
    content= post.content
    user = post.user
    first_name = post.user.first_name
    last_name = post.user.last_name
    fullname = f"{first_name} {last_name}"
    tags = Tag.query.all()
    return render_template('editpost.html', title = title, content = content, fullname = fullname, user = user, post = post, tags = tags)

@app.route('/posts/<int:post_id>/edit', methods=["POST"])
def submit_post_edit(post_id):
    title= request.form["title"]
    content = request.form["content"]

    post = Post.query.filter(Post.id == post_id).one()
    user = post.user

    Post.query.filter(Post.id == post_id).delete()

    new_post = Post(title= title, content = content, user_id= user.id)
    db.session.add(new_post)
    db.session.commit()
    return redirect(f"/users/{user.id}")


@app.route('/posts/<int:post_id>/delete')
def delete_post(post_id):

    post = Post.query.filter(Post.id == post_id).one()
    user = post.user
    Post.query.filter_by(id = post_id).delete()
    db.session.commit()

    return redirect(f"/users/{user.id}")



@app.route('/users/<int:user_id>/edit')
def edit_user(user_id):
    user= User.query.get_or_404(user_id)
    return render_template("edit.html", user=user)

@app.route('/users/<int:user_id>/edit', methods=["POST"])
def submit_edit(user_id):

    user = User.query.get_or_404(user_id)
    user.first_name = request.form["first_name"]
    user.last_name = request.form["last_name"]
    user.image_url = request.form["image_url"]

    db.session.add(user)
    db.session.commit()

    return redirect(f"/users/{user.id}")

# !!!!!!!!!!!!!THE ABOVE SOLVED THE BELOW!!!!!!!!!!!!!!!!!!!

# @app.route('/users/<int:user_id>/edit', methods=["POST"])
# def submit_edit(user_id):
#     user = User.query.filter_by(id = user_id).one()
    
#     user.id= None
#     user.first_name= ""
#     user.last_name= ""
#     user.image_url= ""

#     first_name = request.form["first_name"]
#     last_name = request.form["last_name"]
#     image_url = request.form["image_url"]

#     new_user = User(first_name= first_name, last_name= last_name, image_url = image_url, id= user_id)
#     db.session.add(new_user)
#     db.session.commit()

#     return redirect(f"/users/{user.id}")


    # __________________________________________________________

@app.route('/tags')
def list_tags():
    tags = Tag.query.all()
    return render_template('tags.html', tags = tags)

@app.route('/tags/<tag_id>')
def show_tag(tag_id):
    tag = Tag.query.filter_by(id = tag_id).one()
    return render_template('showtag.html', tag = tag)

@app.route('/tags/new')
def create_tag():
    return render_template("create_tag.html")

@app.route('/tags/new', methods= ["POST"])
def add_tag():
    tag = request.form["tag"]
    new_tag = Tag(name = tag)
    db.session.add(new_tag)
    db.session.commit()
    return redirect('/tags')

@app.route('/tags/<tag_id>/edit')
def edit_tag_form(tag_id):
    tag = Tag.query.filter_by(id = tag_id).one()

    return render_template('edit_tag.html', tag= tag)

@app.route('/tags/<tag_id>/edit', methods =["POST"])
def submit_tag_edit(tag_id):
    new_tag = request.form["edit_tag"]

    Tag.query.filter(Tag.id == tag_id).delete()

    
    edited_tag = Tag(id = new_tag, name = new_tag)
    db.session.add(edited_tag)
    db.session.commit()
    return redirect('/tags')

@app.route('/tags/<tag_id>/delete')
def delete_tag(tag_id):

    Tag.query.filter_by(id = tag_id).delete()
    db.session.commit()

    return redirect('/tags')
   





    



    





