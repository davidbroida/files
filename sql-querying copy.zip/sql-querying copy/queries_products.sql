-- Comments in SQL Start with dash-dash --
INSERT INTO products (name, price,can_be_returned) VALUES ('chair', 44.00, false);
-- Query 1

INSERT INTO products (name, price, can_be_returned) VALUES ('stool', 25.99, 'true');
-- Query 2

INSERT INTO products (name, price, can_be_returned) VALUES ('table', 124.00, false);
-- Query 3

SELECT * FROM products;
-- Query 4

SELECT name FROM products;
-- Query 5

SELECT name, price FROM products;
-- Query 6

INSERT INTO products (name, price, can_be_returned) VALUES ('iPhone_12', 1200, false);
-- Query 7

SELECT * FROM products WHERE can_be_returned = true;
-- Query 8

SELECT *
FROM products
WHERE price < 44;
-- Query 9

SELECT *
FROM products
WHERE price BETWEEN 22.5 AND 99.99;
-- Query 10

UPDATE products SET price = price * 0.8;
-- Query 11

DELETE FROM products WHERE price < 25;
-- Query 12

UPDATE products
SET price = price + 20;
-- Query 13

UPDATE products SET can_be_returned = true;
-- Query 14