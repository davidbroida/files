-- Comments in SQL Start with dash-dash --
SELECT * FROM analytics WHERE id = 1880;
-- Query 1

SELECT id, app_name FROM analytics WHERE last_updated = '2018-08-01';
-- Query 2

SELECT category, COUNT(*)
FROM analytics
GROUP BY category;
-- Query 3

SELECT app_name, reviews FROM analytics ORDER BY reviews DESC limit 5;
-- Query 4

SELECT app_name, reviews, rating
FROM analytics
WHERE rating >= 4.8
ORDER BY reviews DESC limit 1;
-- Query 5

SELECT category, AVG(rating)
FROM analytics
GROUP BY category
ORDER BY AVG(rating) DESC;
-- Query 6

SELECT app_name, price, rating
FROM analytics
WHERE rating < 3
ORDER BY price DESC
LIMIT 1;
-- Query 7

SELECT app_name, min_installs, rating
FROM analytics
WHERE min_installs <= 50 AND
rating >= 0
ORDER BY rating DESC;
-- Query 8

SELECT app_name, rating, reviews
FROM analytics
WHERE rating < 3 AND 
reviews >=10000;
-- Query 9

SELECT app_name, reviews, price
FROM analytics
WHERE price BETWEEN .1 AND 1
ORDER BY reviews DESC
Limit 10;
-- Query 10

SELECT app_name, last_updated
FROM analytics
ORDER BY last_updated ASC
LIMIT 1;
-- Query 11

SELECT app_name, price
FROM analytics
ORDER BY price DESC
LIMIT 1;
-- Query 12

SELECT SUM(reviews)
FROM analytics;
-- Query 13

SELECT category, COUNT(*)
FROM analytics
GROUP BY category
HAVING COUNT(*) > 300;
-- Query 14

SELECT app_name, reviews, min_installs, min_installs/reviews AS proportion 
FROM analytics 
WHERE min_installs >= 100000 
ORDER by Min_installs/reviews DESC 
LIMIT 5;
-- Query 15