"""Forms for playlist app."""

from wtforms.validators import InputRequired
from wtforms import SelectField, StringField
from flask_wtf import FlaskForm


# all_songs = Song.query.all()

class PlaylistForm(FlaskForm):
    """Form for adding playlists."""
    name = StringField("Playlist Name", validators=[InputRequired()])
    description = StringField("Description", validators=[InputRequired()])

class SongForm(FlaskForm):
    """Form for adding songs."""
    title = StringField("Song Title", validators=[InputRequired()])
    artist = StringField("Artist", validators = [InputRequired()])


# DO NOT MODIFY THIS FORM - EVERYTHING YOU NEED IS HERE
class NewSongForPlaylistForm(FlaskForm):
    """Form for adding a song to playlist."""
   
    song = SelectField('Select Song')
