### Conceptual Exercise

Answer the following questions below:

- What is PostgreSQL?
- PostgreSQL is a relational database system. Thus far in the course we have been using it to store data in tables which we've been retreiving "GET requesting" and sending "POST requesting" information to. The basic operations that we impliment can be described with the acronym C.R.U.D. aka creating, removing, updating and deleting data.

- What is the difference between SQL and PostgreSQL?
- SQL stands for Structured Query Language and is simly the language for interacting with databases whereas PosgreSQL is not a language but rather the database management system itself. In other words, PostgreSQL is an SQL platform and SQL is the language which it uses.

- In `psql`, how do you connect to a database?
- In the folder that the .sql file exists in use the command "psql < filename.sql" and then use the command "psql databasename"

- What is the difference between `HAVING` and `WHERE`?
- Both are similar to if statements but WHERE is used in conjunction with GROUP BY. For example a WHERE query would look something like "SELECT * FROM fruits WHERE color = Red. A WHERE query would look something like SELECT * FROM fruits GROUP BY origin HAVING > 2."

- What is the difference between an `INNER` and `OUTER` join?
- An inner join the rows that both tables have in common are returned whereas with an outer join all of the ros from both tables are returned.

- What is the difference between a `LEFT OUTER` and `RIGHT OUTER` join?
- Left and right outer joins will return all of the values from one table but only the rows from the other table that match. A left outer join with return all rows from the left table plus the ros that the right table had in common. A right outer join will return all of the rows from the right table plus the roas that the left table has in common.

- What is an ORM? What do they do?
- ORM stands for Object Relational Mapper and it basically provides a bridge between database tables, relationships and Python objects. For example.. when a Python class is converted it into a table in PosgreSQL a python object & python object's relationships are being mapped into a database by an Object/Relational Mapper.

- What are some differences between making HTTP requests using AJAX 
  and from the server side using a library like `requests`?
  !!!!! I don't know !!!!!!

- What is CSRF? What is the purpose of the CSRF token?
- Cross Site Request Forgery. The purpose of a CSRF token is to prevent a CSRF attack... where a user could potentially think they were submitting / their data somewhere but actually be sending to somewhere else... or someone else with bad intentions.

- What is the purpose of `form.hidden_tag()`?
- form.hidden_tag() generates a hidden field that includes a token which is used to protect the form against CSRF attacks.
