from flask_wtf import FlaskForm
from wtforms import StringField, FloatField, BooleanField, IntegerField, RadioField, SelectField
from wtforms.widgets.core import Select
from wtforms.validators import InputRequired, Email, Optional

ages = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30"]

class AddPetForm(FlaskForm):

    pet_name = StringField("Pet Name", validators=[InputRequired()])
    photo_url = StringField("Photo Url")
    species = SelectField("Species", choices = [('cat', 'Cat'),('dog','Dog'),('porcupine', 'Porcupine')])
    age = SelectField("Age (Years)", choices = [(age,age) for age in ages])
    available = BooleanField("Pet is available")
    notes = StringField("Notes")