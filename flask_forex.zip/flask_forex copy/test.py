from unittest import TestCase
from app import app


class FlaskTest(TestCase):

    def setUp(self):

        self.client = app.test_client()
        app.config['TESTING'] = True

    def test_converter(self):

        with app.test_client() as client:
            resp = client.get('/convert')
            html = resp.get_data(as_text = True)

            self.assertEqual(resp.status_code, 200)
            self.assertIn('$1 USD equals $1.0 USD.', html)


            
