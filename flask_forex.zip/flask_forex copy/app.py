from flask import Flask, redirect, render_template, request, flash
from forex_python.converter import CurrencyRates, CurrencyCodes


app = Flask(__name__)

app.config['SECRET_KEY']= "secret_key"

c = CurrencyRates(force_decimal= False);
cc = CurrencyCodes()


@app.route("/")
def homepage():
    return render_template("home.html")

@app.route("/convert", methods=["GET"])
def convert():

    if (request.args["amount"] == ""):
        flash ("Please enter a valid amount.", 'error')
        return redirect("/")

    convert_from = request.args["converting-from"];
    convert_code = cc.get_symbol(convert_from);
    convert_to = request.args["converting-to"];
    converted_code = cc.get_symbol(convert_to);
    convert_amt = request.args["amount"];


    conversion = c.convert(convert_from, convert_to, int(convert_amt));
    total = round(conversion, 2)

    return render_template("conversion.html", total = total, convert_from = convert_from, convert_to = convert_to, convert_amt = convert_amt, convert_code = convert_code, converted_code = converted_code)


